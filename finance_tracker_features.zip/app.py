
from flask import Flask, render_template
from auth import auth_bp
from api import api_bp

app = Flask(__name__)
app.secret_key = "secret"

app.register_blueprint(auth_bp, url_prefix="/auth")
app.register_blueprint(api_bp, url_prefix="/api")

@app.route("/")
def home():
    return render_template("home.html", title="Finance Tracker")
