from flask import Blueprint, request, jsonify, session
from werkzeug.security import generate_password_hash, check_password_hash

auth_bp = Blueprint('auth', __name__)

users = {}

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.json
    if data['username'] in users:
        return jsonify({"message": "User exists"}), 400
    users[data['username']] = generate_password_hash(data['password'])
    return jsonify({"message": "Registered successfully"})

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    user = users.get(data['username'])
    if user and check_password_hash(user, data['password']):
        session['user'] = data['username']
        return jsonify({"message": "Logged in"})
    return jsonify({"message": "Invalid credentials"}), 401